package com.example.firebaserecyclerviewkotlin

data class User(var firstName : String ?= null,var lastName : String ?= null,var age : String ?= null)
