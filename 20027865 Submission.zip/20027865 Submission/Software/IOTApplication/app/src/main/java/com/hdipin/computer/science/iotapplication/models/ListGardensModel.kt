package com.hdipin.computer.science.iotapplication.models

class ListGardensModel (val gid : String? = null, val gardenTitle: String? = null, val gardenLocation: String? = null)
