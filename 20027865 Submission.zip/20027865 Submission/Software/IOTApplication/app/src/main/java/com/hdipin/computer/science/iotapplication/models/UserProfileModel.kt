package com.hdipin.computer.science.iotapplication.models

data class UserProfileModel ( val profileid: String?, val username : String? ,val firstName : String?, val secondname : String?){
}

/*
*
*
* data class UserProfileModel (val profileid: String?, val username : String? ,val firstName : String?, val secondname : String?, val mobleNo : String?, val uid : String?){
}

* */

