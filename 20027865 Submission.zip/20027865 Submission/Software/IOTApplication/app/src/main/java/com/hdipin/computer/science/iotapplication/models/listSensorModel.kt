package com.hdipin.computer.science.iotapplication.models

class listSensorModel (val DeviceID : String? = null, val Device : String? = null, val Timestamp: String? = null, val Value: String? = null)