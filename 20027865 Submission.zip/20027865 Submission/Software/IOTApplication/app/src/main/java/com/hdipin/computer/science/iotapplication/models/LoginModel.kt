package com.hdipin.computer.science.iotapplication.models




data class LoginModel(val loginid : String?, val username : String? ,val loggedinTime : String?){

}