package com.hdipin.computer.science.iotapplication.models

data class UserModel(val userName : String? = null, val firstName: String? = null, val lastName: String? = null,  val password : String? = null, val uid : String? = null, var age : String ?= null)
