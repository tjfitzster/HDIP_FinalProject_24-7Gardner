package com.hdipin.computer.science.iotapplication.models



data class ScheduleModel(val deveceID : String?, val turnOnDate : String?, val turnOnTime: String?,
                        val scheduleid : String?){

}