package com.hdipin.computer.science.iotapplication.models

data class SensorModel(val DeviceName : String?, val DeviceDate : String?, val DeviceType: Int?, val MeasurmentPin: String?,
                       val gardenID: String?, val devId : String?){


}